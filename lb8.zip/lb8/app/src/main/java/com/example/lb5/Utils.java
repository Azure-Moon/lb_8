package com.example.lb5;

public class Utils {
    public static final String EMAIL = " "; // сюда нужно вставить логин от почты gmail

    public static final String PASS = " "; // сюда нужно вставить пароль от почты gmail

    // при проверке свяжитесь со мной - https://vk.com/id171721963. И я скину данные.
}
